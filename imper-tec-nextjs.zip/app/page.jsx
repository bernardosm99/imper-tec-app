
'use client';
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import Image from "next/image";

const products = {
  "CRV": [
    { name: "Manta Asfáltica CRV 3mm", description: "Impermeabilizante à base de asfalto modificado com polímeros, indicado para lajes, terraços e marquises.", image: "/crv_page_1.png" },
    { name: "Manta Asfáltica CRV Alumínio 3mm", description: "Com acabamento em alumínio, ideal para áreas expostas ao sol como coberturas e marquises.", image: "/crv_page_2.png" },
    { name: "Emulsão Asfáltica CRV", description: "Produto de base aquosa utilizado como primer ou pintura impermeabilizante em fundações e alicerces.", image: "/crv_page_3.png" },
    { name: "Primer Asfáltico CRV", description: "Promove aderência da manta asfáltica em superfícies de concreto.", image: "/crv_page_3.png" }
  ],
  "Casmavi": [
    { name: "Casmavi Vedatop Flex", description: "Impermeabilizante bicomponente flexível para áreas molhadas como banheiros, cozinhas e sacadas.", image: "/casmavi_page_1.png" },
    { name: "Casmavi Vedatop Bianco", description: "Impermeabilizante à base de cimento branco e polímeros. Indicado para caixas d’água e piscinas.", image: "/casmavi_page_2.png" },
    { name: "Casmavi Vedatop Parede", description: "Impermeabilizante acrílico para paredes externas e internas, com alta resistência à umidade.", image: "/casmavi_page_2.png" },
    { name: "Casmavi Vedapren Parede", description: "Membrana acrílica elástica indicada para impermeabilização de fachadas e paredes expostas.", image: "/casmavi_page_3.png" }
  ],
  "Impermeabilizantes": [
    { name: "Imper Asfalto Pintura", description: "Impermeabilizante asfáltico aplicado a frio. Ideal para alicerces, baldrames e muros de arrimo.", image: "/imper_asfalto.png" },
    { name: "Manta Líquida Cinza", description: "Membrana impermeabilizante monocomponente, ideal para lajes e coberturas.", image: "/imper_manta_liquida.png" },
    { name: "Vedaflex", description: "Produto cimentício flexível para áreas molhadas, com alta resistência a pressões positivas e negativas.", image: "/imper_vedaflex.png" },
    { name: "Manta Asfáltica PEAD 3mm", description: "Com filme polietileno de alta densidade, ideal para sistemas enterrados como reservatórios e fundações.", image: "/imper_pead.png" }
  ]
};

export default function ImperTecApp() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4 text-center">Imper Tec Materiais LTDA</h1>
      <Tabs defaultValue="CRV" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="CRV">CRV</TabsTrigger>
          <TabsTrigger value="Casmavi">Casmavi</TabsTrigger>
          <TabsTrigger value="Impermeabilizantes">Impermeabilizantes</TabsTrigger>
        </TabsList>

        {Object.entries(products).map(([category, items]) => (
          <TabsContent value={category} key={category}>
            <ScrollArea className="h-96">
              <div className="grid gap-4 mt-4">
                {items.map((product, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      {product.image && (
                        <div className="mb-2">
                          <Image
                            src={product.image}
                            alt={product.name}
                            width={400}
                            height={200}
                            className="rounded-lg object-cover"
                          />
                        </div>
                      )}
                      <h2 className="text-lg font-semibold">{product.name}</h2>
                      <p>{product.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
